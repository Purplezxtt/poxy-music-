# Poxy Music

Player de música pessoal que roda no navegador e pode ser instalado no celular como app. Você adiciona seus áudios, ouve, baixa e continua ouvindo com a tela apagada. Os arquivos ficam guardados só no aparelho de quem usa. Não existe servidor.

## Publicar no GitHub Pages

1. Entre em github.com, toque em **New repository**, dê um nome (por exemplo `poxy-music`) e marque **Public**. Crie o repositório.
2. Extraia o .zip no seu computador. Dentro da pasta `poxy-music` estão `index.html`, `manifest.webmanifest`, `sw.js` e a pasta `icons`.
3. No repositório, toque em **Add file** e depois **Upload files**. Arraste o conteúdo da pasta (os arquivos e a pasta `icons`, não a pasta `poxy-music` em si) e toque em **Commit changes**.
4. Vá em **Settings**, depois **Pages**. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`. Salve.
5. Espere cerca de um minuto. O endereço aparece na mesma tela e tem este formato: `https://SEU-USUARIO.github.io/poxy-music/`

## Instalar como app

- **Android (Chrome):** abra o endereço, toque nos três pontos e escolha **Instalar app** ou **Adicionar à tela inicial**.
- **iPhone (Safari):** abra o endereço, toque no botão de compartilhar e escolha **Adicionar à Tela de Início**.
- **Computador (Chrome ou Edge):** use o ícone de instalar na barra de endereço.

## Como funciona

- A biblioteca fica no armazenamento do navegador (IndexedDB). Limpar os dados do site apaga as músicas.
- Cada pessoa que abrir o endereço tem a sua própria biblioteca, vazia no começo.
- Baixar salva o arquivo de áudio original. Baixar tudo gera um .zip.
- Com a música tocando, os controles aparecem na notificação e na tela de bloqueio. Isso depende do navegador e do aparelho.
- Depois da primeira visita, o app abre sem internet. A busca por fontes e o .zip de "Baixar tudo" precisam de conexão na primeira vez.

## Mudar o app depois

Edite o `index.html` direto no GitHub (ícone de lápis). Ao mudar qualquer arquivo, troque o número em `CACHE = 'poxy-music-v1'` no `sw.js` (para `v2`, `v3`...) para que quem já instalou receba a versão nova.
